$(document).ready(function()
{
    $("#button1").click(function()
    {
       $("#para1").animate({fontSize:"40px"},3000)
        
    });
    $("#button2").click(function()
    {
       $("#para2").animate({fontSize:"40px"},3000)
        
    });
    $("#button3").click(function()
    {
       $("#para3").animate({fontSize:"40px"},3000)
        
    });
    
});