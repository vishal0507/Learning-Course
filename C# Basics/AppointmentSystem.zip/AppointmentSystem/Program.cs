﻿using System;
using System.Collections.Generic;
namespace AppointmentSystem;
class Program
{
    public static void Main(string[] args)
    {
        AppointmentManager.DefaultDatas();
        AppointmentManager.MainMenu();


    }
}
